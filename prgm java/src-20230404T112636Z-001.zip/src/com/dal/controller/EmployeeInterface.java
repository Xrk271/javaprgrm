package com.dal.controller;

public interface EmployeeInterface {
	public void addEmployee();
	public void viewEmployee() ;
}
