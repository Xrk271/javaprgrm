package com.extra.tightcouple;

public class Bike {
	public void move() {
		System.out.println("Bike is moving...");
	}

}
