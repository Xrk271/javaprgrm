package com.extra.tightcouple;

public class Bus {
	public void move() {
		System.out.println("Bus is moving...");
	}

}
