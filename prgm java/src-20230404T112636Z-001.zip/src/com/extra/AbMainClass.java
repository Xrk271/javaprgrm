package com.extra;

//abstract class Animal{
//	
//	//public abstract void eat();
//	
//}
//
//class Dog extends Animal
//{
//	
//}
//
//class Lion{
//	
//	
//}




public class AbMainClass {

	public static void main(String[] args) {
		//Animal ani;

	}

}
