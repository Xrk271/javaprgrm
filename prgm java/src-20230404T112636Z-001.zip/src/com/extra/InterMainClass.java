package com.extra;

interface Vehicle{
	
	//protected int x=77;
	public  void move();
//	public  void stop() {}
	
}

/*class Dog implements Animal
{
	
}*/

class Lion{
	
	
}


public class InterMainClass {

}
